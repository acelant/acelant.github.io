$(function(){
	
    $("#relatorio").dxPivotGrid({
        allowSortingBySummary: true,
        allowSorting: true,
        allowFiltering: true,
        allowExpandAll: true,
        //height: 500,
        showBorders: true,
		showTotalsPrior: "rows",
		rowHeaderLayout: "tree",
		showRowGrandTotals: true,
		showColumnGrandTotals: true,
		showColumnTotals: true,
        texts: {
            collapseAll: "Recolher todos",
            dataNotAvailable: "N/A",
            expandAll: "Expandir todos",
            exportToExcel: "Exportar para arquivo do Excel",
            grandTotal: "Total Geral",
            noData: "Sem dados",
            removeAllSorting: "Remover toda a classificação",
            showFieldChooser: "Mostrar lista de campos",
            sortColumnBySummary: "Ordenar {0} por esta coluna",
            sortRowBySummary: "Ordenar {0} por esta linha",
            total: "{0} Total"
            },
        fieldChooser: {
            enabled: true,
            applyChangesMode: "instantly",
            allowSearch: false,
            title: "Lista de Campos",
            texts: {
                allFields: "Campos",
                columnFields: "Colunas",
                dataFields: "Valores",
                rowFields: "Linhas",
                filterFields: "Filtros"
            }
        },
       fieldPanel: {
            showColumnFields: true,
            showDataFields: true,
            showFilterFields: false,
            showRowFields: true,
            allowFieldDragging: true,
            visible: true
	    },
        /*stateStoring: {
            enabled: true,
            type: "localStorage",
            storageKey: "demonstrativo-fechamentos"
        },*/
        "export": {
            enabled: true,
            fileName: "Projecao Fluxo Caixa"
        },
        onCellPrepared: function(e) {
                
                e.cellElement.css("font-size", "14px");
                if(e.area == "data"){
                    if(e.cell.value < 0 ){
                        e.cellElement.css("color", "red");

                    }
                }
        },        
        dataSource: {
            fields: [{
                caption: "Opção",
                width: 120,
                dataField: "nivel1",
                area: "row" 
            }, {
                caption: "Opção 2",
                dataField: "nivel2",
                width: 120,
                area: "row"
			}, {
                caption: "Opção 3",
                dataField: "nivel3",
                width: 120,
                area: "row"
            }, {
                caption: "Ano",
				dataField: "ano",
				area: "column",
                displayFolder: 'Data'
            }, {
                caption: "Mês",
                dataField: "mes",
                area: "column",
                displayFolder: 'Data'
            }, {
                caption: "Dia",
				dataField: "dia",
				area: "column",
                displayFolder: 'Data'
			}, {
                caption: "Valor",
                dataField: "valor",
                dataType: "number",
                summaryType: "sum",
                format: "fixedPoint",
				precision: 2,
                area: "data"
            }],
            store: relatorio
        }
		
    });
}
 
);
